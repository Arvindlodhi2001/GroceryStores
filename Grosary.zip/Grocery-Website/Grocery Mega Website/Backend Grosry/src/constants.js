export const DB_NAME = "Grocery";
export const PORT = 2020;

export const MONGODB_URI =
  "mongodb+srv://Grocery:GroceryPassword%40123@cluster0.gc8rq.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0";

export const ACCESS_TOKEN_SECRET =
  "a3f4e2b6d7c8e9f01234567890abcdef1234567890abcdef1234567890abcdef";

export const ACCESS_TOKEN_EXPIRE = "1d";

export const REFRESH_TOKEN_SECRET =
  "f9a8e7c6d5b4a31234567890abcdef1234567890abcdef1234567890abcdef";

export const REFRESH_TOKEN_EXPIRE = "10d";

//  cloudinary Configuration

export const CLOUDINARY_NAME = "dfxqem8nb";

export const CLOUDINARY_API_KEY = "775734745811181";

export const CLOUDINARY_API_SECRET = "mh6jhHtmT2YOpfbnQXBcJ2KYTDU";
